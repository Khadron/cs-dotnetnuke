'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data

Namespace DotNetNuke.Modules.Reports

    ''' <summary>
    ''' Stores information about a single report that can be displayed by the module
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[anurse]	06/16/2006	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class ReportInfo

#Region " Private Fields "

        Private _ModuleID As Integer
        Private _Title As String
        Private _Description As String
        Private _Query As String
        Private _CreatedBy As Integer
        Private _CreatedOn As DateTime

#End Region

#Region " Public Constructor "

        ''' <summary>
        ''' Constructs an empty <see cref="ReportInfo"/> object
        ''' </summary>
        ''' <remarks></remarks>
        ''' <history>
        ''' 	[anurse]	06/16/2006	Created
        ''' </history>
        Public Sub New()
        End Sub

#End Region

#Region " Public Properties "

        ''' <summary>
        ''' Gets or sets the module ID of the report
        ''' </summary>
        ''' <returns>The module ID of the report</returns>
        ''' <history>
        ''' 	[anurse]	06/19/2006	Created
        ''' </history>
        Public Property ModuleID() As Integer
            Get
                Return _ModuleID
            End Get
            Set(ByVal Value As Integer)
                _ModuleID = Value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the title of the report
        ''' </summary>
        ''' <returns>The title of the report</returns>
        ''' <history>
        ''' 	[anurse]	06/16/2006	Created
        ''' </history>
        Public Property Title() As String
            Get
                Return _Title
            End Get
            Set(ByVal Value As String)
                _Title = Value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets a short description of the report
        ''' </summary>
        ''' <returns>A short description of the report</returns>
        ''' <history>
        ''' 	[anurse]	06/16/2006	Created
        ''' </history>
        Public Property Description() As String
            Get
                Return _Description
            End Get
            Set(ByVal Value As String)
                _Description = Value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the query used to build the report
        ''' </summary>
        ''' <returns>The query used to build the report</returns>
        ''' <history>
        ''' 	[anurse]	06/16/2006	Created
        ''' </history>
        Public Property Query() As String
            Get
                Return _Query
            End Get
            Set(ByVal Value As String)
                _Query = Value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the user ID of the user who created this report
        ''' </summary>
        ''' <returns>The user ID of the user who created this report</returns>
        ''' <history>
        ''' 	[anurse]	06/16/2006	Created
        ''' </history>
        Public Property CreatedBy() As Integer
            Get
                Return _CreatedBy
            End Get
            Set(ByVal value As Integer)
                _CreatedBy = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the date that this report was created
        ''' </summary>
        ''' <returns>The date that this report was created</returns>
        Public Property CreatedOn() As DateTime
            Get
                Return _CreatedOn
            End Get
            Set(ByVal value As DateTime)
                _CreatedOn = value
            End Set
        End Property

#End Region

    End Class

End Namespace
