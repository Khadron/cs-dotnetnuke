'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.Xml
Imports System.Web
Imports System.Collections.Generic
Imports DotNetNuke
Imports DotNetNuke.Services.Search
Imports DotNetNuke.Common.Utilities.XmlUtils

Namespace DotNetNuke.Modules.Reports

    ''' <summary>
    ''' The Controller class for Reports
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[anurse]	06/16/2006	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class ReportsController
        Implements Entities.Modules.ISearchable
        Implements Entities.Modules.IPortable

#Region " Public Constants "

        Public Const SETTING_ReportTitle As String = "dnn_ReportTitle"
        Public Const SETTING_ReportDescription As String = "dnn_ReportDescription"
        Public Const SETTING_ReportQuery As String = "dnn_ReportQuery"
        Public Const SETTING_ReportCreatedBy As String = "dnn_ReportCreatedBy"
        Public Const SETTING_ReportCreatedOn As String = "dnn_ReportCreatedOn"
        Public Const SETTING_EnablePaging As String = "dnn_ReportEnablePaging"
        Public Const SETTING_EnableSorting As String = "dnn_ReportEnableSorting"
        Public Const SETTING_PageSize As String = "dnn_ReportPageSize"
        Public Const SETTING_ShowHeader As String = "dnn_ReportShowHeader"

        Public Const CACHEKEY_Reports As String = "dnn_ReportCache"

        Public Const MODULE_VERSION As String = "04.03.01"

#End Region

#Region " Public Methods "

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the report associated with a reports module
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModuleId">The Id of the module</param>
        ''' <history>
        ''' 	[anurse]	06/16/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetReport(ByVal ModuleId As Integer) As ReportInfo

            ' Extract the Title, Description and Query from the settings
            Dim objModuleController As New DotNetNuke.Entities.Modules.ModuleController
            Dim objSettings As Hashtable = objModuleController.GetModuleSettings(ModuleId)
            Dim objReport As New ReportInfo()
            Dim strNotSpecified As String = String.Format("<{0}>", Localization.GetString("Not_Specified.Text"))

            objReport.Query = ExtractString(objSettings(ReportsController.SETTING_ReportQuery), Null.NullString)
            If String.IsNullOrEmpty(objReport.Query) Then
                Return Nothing ' If there's no query, there's no report
            End If

            objReport.Title = ExtractString(objSettings(ReportsController.SETTING_ReportTitle), strNotSpecified)
            objReport.Description = ExtractString(objSettings(ReportsController.SETTING_ReportDescription), strNotSpecified)
            objReport.CreatedOn = ExtractDate(objSettings(ReportsController.SETTING_ReportCreatedOn))
            objReport.CreatedBy = ExtractInteger(objSettings(ReportsController.SETTING_ReportCreatedBy))
            objReport.ModuleID = ModuleId
            Return objReport

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Sets the report associated with a reports module
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModuleId">The ModuleId to set the report for</param>
        ''' <param name="objReport">The ReportInfo object</param>
        ''' <history>
        ''' 	[anurse]	06/16/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub SetReport(ByVal ModuleId As Integer, ByVal objReport As ReportInfo)

            ' Update the module settings with the data from the report
            Dim objModuleController As New DotNetNuke.Entities.Modules.ModuleController
            objModuleController.UpdateModuleSetting(ModuleId, ReportsController.SETTING_ReportTitle, objReport.Title)
            objModuleController.UpdateModuleSetting(ModuleId, ReportsController.SETTING_ReportDescription, objReport.Description)
            objModuleController.UpdateModuleSetting(ModuleId, ReportsController.SETTING_ReportQuery, objReport.Query)
            objModuleController.UpdateModuleSetting(ModuleId, ReportsController.SETTING_ReportCreatedOn, objReport.CreatedOn)
            objModuleController.UpdateModuleSetting(ModuleId, ReportsController.SETTING_ReportCreatedBy, objReport.CreatedBy)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Executes a report and returns the results
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="objReport">The ReportInfo object</param>
        ''' <exception cref="System.ArgumentNullException">
        ''' The value of <paramref name="objReport"/> was null (Nothing in Visual Basic)
        ''' </exception>
        ''' <history>
        ''' 	[anurse]	06/16/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function ExecuteReport(ByVal objReport As ReportInfo) As DataTable

            If objReport Is Nothing Then Throw New ArgumentNullException("objReport")

            If String.IsNullOrEmpty(objReport.Query) Then
                Return Nothing ' If there's no query, there's no report
            Else
                Dim strCacheKey As String = String.Concat(CACHEKEY_Reports, objReport.ModuleID)
                Dim objCache As Object = DataCache.GetCache(strCacheKey)
                Dim dataTable As DataTable = Nothing
                If objCache IsNot Nothing AndAlso TypeOf objCache Is DataTable Then
                    dataTable = DirectCast(objCache, DataTable)
                Else
                    Dim dr As IDataReader = DataProvider.Instance().ExecuteSQL(objReport.Query)
                    If dr Is Nothing Then Return Nothing
                    dataTable = New DataTable("QueryResults")
                    dataTable.Load(dr)
                    DataCache.SetCache(strCacheKey, dataTable)
                End If
                Return dataTable
            End If

        End Function

        '''-----------------------------------------------------------------------------
        ''' <summary>
        ''' Removes "Bad" SQL Commands from the specified string
        ''' </summary>
        ''' <param name="strSQL">This is the string to be filtered</param>
        ''' <returns>A filtered version of <paramref name="strSQL" /> with commands such as INSERT or DELETE removed</returns>
        ''' <history>
        '''     [anurse]        6/20/2006   Created
        ''' </history>
        '''-----------------------------------------------------------------------------
        Public Shared Function FormatRemoveSQL(ByVal strSQL As String) As String

            Dim strCleanSQL As String = strSQL

            If strSQL <> Nothing Then

                ' each string in this array is one that must be removed from the SQL
                Dim BadSQL As String() = New String() {";", "--", "create", "drop", "insert", "delete", "update", "sp_", "xp_"}

                ' strip any dangerous SQL commands
                Dim intCommand As Integer
                For intCommand = 0 To BadSQL.Length - 1
                    ' remove the current item in the "Bad SQL" list from the string by replacing it with a space
                    strCleanSQL = Regex.Replace(strCleanSQL, Convert.ToString(BadSQL.GetValue(intCommand)), " ", _
                        RegexOptions.IgnoreCase)
                Next
            End If

            ' return the clean SQL
            Return strCleanSQL

        End Function

        '''-----------------------------------------------------------------------------
        ''' <summary>
        ''' Clears the results that have been cached by the module.
        ''' </summary>
        ''' <param name="ModuleID">The ID of the module to clear cached results for</param>
        ''' <history>
        '''     [anurse]        6/20/2006   Created
        '''     [anurse]        6/21/2006   Documented
        ''' </history>
        '''-----------------------------------------------------------------------------
        Public Shared Sub ClearCachedResults(ByVal ModuleID As Integer)
            DataCache.RemoveCache(String.Concat(CACHEKEY_Reports, ModuleID))
        End Sub

#End Region

#Region " Optional Interfaces "

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetSearchItems implements the ISearchable Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModInfo">The ModuleInfo for the module to be Indexed</param>
        ''' <history>
        ''' 	[anurse]	06/16/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As DotNetNuke.Services.Search.SearchItemInfoCollection Implements DotNetNuke.Entities.Modules.ISearchable.GetSearchItems

            ' Get the report
            Dim objReport As ReportInfo = GetReport(ModInfo.ModuleID)

            ' Execute the report and serialize it to Xml
            Dim objTable As DataTable = ExecuteReport(objReport)
            Dim sbContent As New StringBuilder
            If objTable IsNot Nothing Then
                objTable.WriteXml(New System.IO.StringWriter(sbContent))
            End If

            ' Build a search item
            Dim objPortalSec As New PortalSecurity
            Dim objSearchItem As New SearchItemInfo(objReport.Title, _
                objPortalSec.InputFilter(objReport.Description, PortalSecurity.FilterFlag.NoMarkup), objReport.CreatedBy, _
                objReport.CreatedOn, ModInfo.ModuleID, String.Empty, sbContent.ToString())

            ' Add it to the collection and return
            Dim objSearchItems As New SearchItemInfoCollection()
            objSearchItems.Add(objSearchItem)
            Return objSearchItems

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ExportModule implements the IPortable ExportModule Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModuleID">The Id of the module to be exported</param>
        ''' <history>
        ''' 	[anurse]	06/16/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements DotNetNuke.Entities.Modules.IPortable.ExportModule
            Dim objReport As ReportInfo = GetReport(ModuleID)
            If objReport Is Nothing Then
                Return String.Empty
            End If

            Dim xmlBuilder As New StringBuilder
            xmlBuilder.AppendFormat("<title><![CDATA[{0}]]></title>", objReport.Title)
            xmlBuilder.AppendFormat("<description><![CDATA[{0}]]></description>", objReport.Description)

            ' Obscure the query...it isn't much, but it will help if Hosts want to protect their queries from prying eyes
            Dim queryBytes As Byte() = Encoding.Default.GetBytes(objReport.Query)
            xmlBuilder.AppendFormat("<query><![CDATA[{0}]]></query>", Convert.ToBase64String(queryBytes))
            Return xmlBuilder.ToString()
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ImportModule implements the IPortable ImportModule Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModuleID">The Id of the module to be imported</param>
        ''' <param name="Content">The content to be imported</param>
        ''' <param name="Version">The version of the module to be imported</param>
        ''' <param name="UserId">The Id of the user performing the import</param>
        ''' <history>
        ''' 	[anurse]	06/16/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements DotNetNuke.Entities.Modules.IPortable.ImportModule

            ' Check Access and Version
            Dim objUser As UserInfo = UserController.GetUser(-1, UserId, False)
            If objUser Is Nothing OrElse Not objUser.IsSuperUser OrElse Not Version.Equals(MODULE_VERSION) Then Return

            Dim objNewReport As New ReportInfo
            Dim xmlDoc As New XmlDocument
            xmlDoc.LoadXml(String.Format("<content>{0}</content>", Content))
            Dim xmlRoot As XmlElement = xmlDoc.DocumentElement

            objNewReport.Title = XmlUtils.GetNodeValue(xmlRoot, "title", String.Empty)
            objNewReport.Description = XmlUtils.GetNodeValue(xmlRoot, "description", String.Empty)
            objNewReport.CreatedOn = DateTime.Now
            objNewReport.CreatedBy = UserId

            ' Deobscure the query
            Dim b64Query As String = XmlUtils.GetNodeValue(xmlRoot, "query", String.Empty)
            Dim query As String
            If String.IsNullOrEmpty(b64Query) Then
                query = String.Empty
            Else
                Dim queryBytes As Byte() = Convert.FromBase64String(b64Query)
                query = Encoding.Default.GetString(queryBytes)
            End If
            objNewReport.Query = query

            SetReport(ModuleID, objNewReport)
            ClearCachedResults(ModuleID)
        End Sub

#End Region

#Region " Private Helper Functions "

        Private Shared Function ExtractString(ByVal obj As Object, ByVal strNullString As String) As String
            If obj Is Nothing Then
                Return strNullString
            Else
                Return obj.ToString()
            End If
        End Function

        Private Shared Function ExtractDate(ByVal obj As Object) As DateTime
            Dim dateRet As DateTime = Null.NullDate
            If obj IsNot Nothing Then
                Try
                    dateRet = DateTime.Parse(obj.ToString())
                Catch ex As FormatException
                    ' make sure dateRet is set to null
                    dateRet = Null.NullDate
                End Try
            End If
            Return dateRet
        End Function

        Private Shared Function ExtractInteger(ByVal obj As Object) As Integer
            Dim intRet As Integer = Null.NullInteger
            If obj IsNot Nothing Then
                Try
                    intRet = Integer.Parse(obj.ToString())
                Catch ex As FormatException
                    ' make sure intRet is set to null
                    intRet = Null.NullInteger
                End Try
            End If
            Return intRet
        End Function

#End Region

    End Class
End Namespace
