'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke
Imports System.Web.UI

Namespace DotNetNuke.Modules.Reports

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The Settings class manages Module Settings
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Partial Class Settings
        Inherits Entities.Modules.ModuleSettingsBase

#Region "Base Method Implementations"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' LoadSettings loads the settings from the Database and displays them
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub LoadSettings()
            Try
                If Not CheckPermissions() Then Return

                If (Page.IsPostBack = False) Then
                    Dim objReport As ReportInfo = ReportsController.GetReport(ModuleId)
                    If objReport IsNot Nothing Then
                        txtTitle.Text = objReport.Title
                        txtDescription.Text = objReport.Description
                        txtQuery.Text = objReport.Query
                    End If
                    chkPage.Checked = Convert.ToBoolean(TabModuleSettings(ReportsController.SETTING_EnablePaging))
                    chkSort.Checked = Convert.ToBoolean(TabModuleSettings(ReportsController.SETTING_EnableSorting))
                    txtPageSize.Text = Convert.ToString(TabModuleSettings(ReportsController.SETTING_PageSize))

                    rowPageSize.Visible = chkPage.Checked

                    ' Default is true for this setting, unlike others
                    If TabModuleSettings(ReportsController.SETTING_ShowHeader) IsNot Nothing Then
                        chkShowHeader.Checked = Convert.ToBoolean(TabModuleSettings(ReportsController.SETTING_ShowHeader))
                    Else
                        chkShowHeader.Checked = True
                    End If
                End If
            Catch exc As Exception           'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' UpdateSettings saves the modified settings to the Database
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub UpdateSettings()
            Try
                ' Do not update report specification if the user is not a SuperUser
                If Me.UserInfo.IsSuperUser Then
                    Dim objReport As New ReportInfo()
                    Dim objSecurity As New PortalSecurity
                    objReport.Title = txtTitle.Text
                    objReport.Description = objSecurity.InputFilter(txtDescription.Text, PortalSecurity.FilterFlag.NoScripting)
                    objReport.Query = ReportsController.FormatRemoveSQL(txtQuery.Text)
                    objReport.CreatedBy = Me.UserId
                    objReport.CreatedOn = DateTime.Now

                    ReportsController.SetReport(ModuleId, objReport)
                    ReportsController.ClearCachedResults(Me.ModuleId)
                End If

                ' Non-SuperUsers can change TabModuleSettings (display settings)
                Dim objModuleController As New DotNetNuke.Entities.Modules.ModuleController
                objModuleController.UpdateTabModuleSetting(TabModuleId, ReportsController.SETTING_EnablePaging, chkPage.Checked)
                objModuleController.UpdateTabModuleSetting(TabModuleId, ReportsController.SETTING_EnableSorting, chkSort.Checked)
                objModuleController.UpdateTabModuleSetting(TabModuleId, ReportsController.SETTING_PageSize, txtPageSize.Text)
                objModuleController.UpdateTabModuleSetting(TabModuleId, ReportsController.SETTING_ShowHeader, chkShowHeader.Checked)

                ' refresh cache
                SynchronizeModule()
            Catch exc As Exception           'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

#Region " Event Handlers "

        Protected Sub chkPage_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkPage.CheckedChanged
            rowPageSize.Visible = chkPage.Checked
        End Sub

#End Region

#Region " Private Methods "

        Private Function CheckPermissions() As Boolean
            If Not Me.UserInfo.IsSuperUser Then
                ReportsSettingsMultiView.SetActiveView(AccessDeniedView)
                Return False
            Else
                ReportsSettingsMultiView.SetActiveView(SuperUserView)
                Return True
            End If
        End Function

#End Region

    End Class

End Namespace

