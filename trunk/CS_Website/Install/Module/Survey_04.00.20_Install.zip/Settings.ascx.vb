'
' DotNetNuke - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports System.Runtime.Serialization.Formatters
Imports DotNetNuke

Namespace DotNetNuke.Modules.Survey

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The Settings ModuleSettingsBase is used to manage the 
    ''' settings for the Survey Module
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	    10/22/2004	Updated to reflect design changes for Help, 508 support
    '''                       and localisation
    '''		[cnurse]	    10/22/2004	Converted to a ModuleSettingsBase class
    '''     [mwashington]	8/12/2006	Converted to ASP.NET 2.0
    ''' 
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Partial Public Class Settings
        Inherits DotNetNuke.Entities.Modules.ModuleSettingsBase

#Region "Base Method Implementations"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' LoadSettings loads the settings from the Database and displays them
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''		[cnurse]	10/22/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub LoadSettings()
            Try
                'this needs to execute always to the client script code is registred in InvokePopupCal
                cmdCalendar.NavigateUrl = DotNetNuke.Common.Utilities.Calendar.InvokePopupCal(txtClosingDate)

                If (Page.IsPostBack = False) Then

                    If CType(ModuleSettings("surveyclosingdate"), String) <> "" Then
                        txtClosingDate.Text = CType(ModuleSettings("surveyclosingdate"), Date).ToShortDateString
                    End If
                    txtGraphWidth.Text = CType(TabModuleSettings("surveygraphwidth"), String)
                    rblstPersonal.SelectedIndex = CType(ModuleSettings("surveytracking"), Integer)
                    rblstSurveyResults.SelectedIndex = CType(ModuleSettings("surveyresultstype"), Integer)
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' UpdateSettings saves the modified settings to the Database
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''		[cnurse]	10/22/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub UpdateSettings()
            Try
                Dim objModules As New DotNetNuke.Entities.Modules.ModuleController

                Dim datClosingDate As Date = Null.NullDate
                If txtClosingDate.Text.Trim.Length > 0 Then
                    datClosingDate = Convert.ToDateTime(txtClosingDate.Text.Trim)
                End If

                'Update Module Settings
                objModules.UpdateModuleSetting(ModuleId, "surveyclosingdate", DotNetNuke.Common.Globals.DateToString(datClosingDate))
                objModules.UpdateModuleSetting(ModuleId, "surveytracking", (rblstPersonal.SelectedIndex).ToString)
                objModules.UpdateModuleSetting(ModuleId, "surveyresultstype", (rblstSurveyResults.SelectedIndex).ToString)

                'Update Tab Module Settings
                objModules.UpdateTabModuleSetting(TabModuleId, "surveygraphwidth", txtGraphWidth.Text)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

    End Class

End Namespace


